function showConfirmation() {
    alert("Your submission has been received!");
}